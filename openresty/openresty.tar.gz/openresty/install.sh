rpm -ivh stor-pcre-8.39-3.el7.centos.x86_64.rpm
rpm -ivh stor-zlib-1.2.11-1.el7.centos.x86_64.rpm
rpm -ivh stor-openssl-1.0.2j-3.el7.centos.x86_64.rpm
yum -y install yum install GeoIP 
rpm -ivh stor-openresty-1.11.2.2-9.el7.centos.x86_64.rpm
