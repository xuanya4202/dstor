#!/bin/bash

PORT=55667
REDIS_PACK=redis-3.2.8-1.el7.centos.x86_64.rpm

rpmname=`echo $REDIS_PACK|awk -F '-' '{print $1"-"$2}'`
nodes={}
parse_conf()
{
    local i=0
    for host in `cat config`;
    do
        if [[ `echo $host|cut -c 1` != "#" ]]; then
            echo $host $i
            nodes[i]=$host
            i=$[$i+1]
        fi
    done
}

deploy()
{
    local all_node=""
    for host in ${nodes[@]};
	do
        #seq 1
        echo ssh -p $PORT $host  "yum install rubygems -y"
        ssh -p $PORT $host  "yum install rubygems -y"
        if [ $? -ne 0 ] ;then
            echo " yum install rubygems -y failed. node:" $host
            return
        fi
        
        #seq 2
        echo scp -P $PORT $REDIS_PACK  root@$host:/usr/local/
        scp -P $PORT $REDIS_PACK  root@$host:/usr/local/
        if [ $? -ne 0 ] ;then
            echo " scp $REDIS_PACK failed. node:" $host
            return
        fi
        
        #seq 3
        echo ssh -p $PORT $host  "cd /usr/local/; rpm -ivh $REDIS_PACK"
        ssh -p $PORT $host  "cd /usr/local/; rpm -ivh $REDIS_PACK"
        if [ $? -ne 0 ] ;then
            echo " rpm -ivh $REDIS_PACK failed. node:" $host
            return
        fi
        
        #seq 4
        local cmd="sed -i 's/bind 127.0.0.1/bind $host 127.0.0.1/g'  /usr/local/$rpmname/conf/redis-6082.conf"
        echo ssh -p $PORT $host $cmd
        ssh -p $PORT $host $cmd
        if [ $? -ne 0 ] ;then
            echo " sed conf failed. node:" $host
            return
        fi
        
        #seq 5
        echo ssh -p $PORT $host "systemctl start stor-redis@6082"
        ssh -p $PORT $host "systemctl start stor-redis@6082"
        if [ $? -ne 0 ] ;then
            echo " systemctl start stor-redis failed. node:" $host
            return
        fi
        
        all_node=$all_node" "$host":6082"
    done

    #seq 6
    local cmd="cd /usr/local/$rpmname/bin/; ./redis-trib.rb create --replicas 1 $all_node"
    echo ssh -p $PORT $host $cmd
    ssh -p $PORT $host $cmd
    if [ $? -ne 0 ] ;then
        echo " create replicas failed. node:" $host
        return
    fi
}
parse_conf
deploy
